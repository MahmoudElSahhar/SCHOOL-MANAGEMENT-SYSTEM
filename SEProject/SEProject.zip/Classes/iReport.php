<?php

interface iReport
{
    public static function GenerateReport();
}


?>