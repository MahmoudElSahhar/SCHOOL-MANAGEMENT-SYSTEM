<?php

interface iOrder
{
    public function putTaxes();
    public function putDiscount();
}

?>