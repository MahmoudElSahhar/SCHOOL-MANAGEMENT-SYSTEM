<?php

    interface iObserver
    {
        public function refresh($Notification, $User);
    }

?>